# Spartan App - Confirmação de Email

Este diretório contém a página de confirmação de email que redireciona para o aplicativo.
